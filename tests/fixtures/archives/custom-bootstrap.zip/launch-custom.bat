@echo off
java -jar custom-wrapper.jar
